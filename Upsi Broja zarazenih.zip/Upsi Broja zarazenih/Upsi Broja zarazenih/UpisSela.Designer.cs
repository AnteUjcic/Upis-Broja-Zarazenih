﻿namespace Upsi_Broja_zarazenih
{
    partial class UpisSela
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtUpisSela = new System.Windows.Forms.TextBox();
            this.txtIDSela = new System.Windows.Forms.TextBox();
            this.btnUpisSela = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtUpisSela
            // 
            this.txtUpisSela.Location = new System.Drawing.Point(6, 37);
            this.txtUpisSela.Name = "txtUpisSela";
            this.txtUpisSela.Size = new System.Drawing.Size(100, 20);
            this.txtUpisSela.TabIndex = 0;
            this.txtUpisSela.TextChanged += new System.EventHandler(this.txtUpisSela_TextChanged);
            // 
            // txtIDSela
            // 
            this.txtIDSela.Location = new System.Drawing.Point(6, 75);
            this.txtIDSela.Name = "txtIDSela";
            this.txtIDSela.Size = new System.Drawing.Size(100, 20);
            this.txtIDSela.TabIndex = 1;
            this.txtIDSela.TextChanged += new System.EventHandler(this.txtIDSela_TextChanged);
            // 
            // btnUpisSela
            // 
            this.btnUpisSela.Location = new System.Drawing.Point(154, 109);
            this.btnUpisSela.Name = "btnUpisSela";
            this.btnUpisSela.Size = new System.Drawing.Size(75, 23);
            this.btnUpisSela.TabIndex = 2;
            this.btnUpisSela.Text = "Upis";
            this.btnUpisSela.UseVisualStyleBackColor = true;
            this.btnUpisSela.Click += new System.EventHandler(this.btnUpisSela_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtUpisSela);
            this.groupBox1.Controls.Add(this.btnUpisSela);
            this.groupBox1.Controls.Add(this.txtIDSela);
            this.groupBox1.Location = new System.Drawing.Point(25, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(242, 142);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Upis sela";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "ID sela";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Ime sela";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // UpisSela
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(347, 196);
            this.Controls.Add(this.groupBox1);
            this.Name = "UpisSela";
            this.Text = "UpisSela";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtUpisSela;
        private System.Windows.Forms.TextBox txtIDSela;
        private System.Windows.Forms.Button btnUpisSela;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}