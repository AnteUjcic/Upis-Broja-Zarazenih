﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Upsi_Broja_zarazenih
{
    internal class Selo
    {
        string imeSela;
        int IDSela;

        public Selo(string imeSela, int iDSela)
        {
            this.imeSela = imeSela;
            IDSela = iDSela;
        }

        public string ImeSela { get => imeSela; set => imeSela = value; }
        public int IDSela1 { get => IDSela; set => IDSela = value; }
    }
}
